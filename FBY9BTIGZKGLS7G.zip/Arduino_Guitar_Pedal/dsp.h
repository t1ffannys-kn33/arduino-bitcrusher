#define left 0
#define right 1

void setupIO();
void output(int channel, short value);
